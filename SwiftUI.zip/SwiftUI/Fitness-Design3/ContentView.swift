//
//  ContentView.swift
//  Fitness-Design3
//
//  Created by Alexandru Bardea on 20/03/2021.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            
            VStack(alignment: .leading){
            HStack{
                Spacer()
                VStack{
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 35, height: 8)
                    RoundedRectangle(cornerRadius: 20)
                        .frame(width: 25, height: 8)
                }
            }
            .padding(.trailing,30)
            Text("Workout")
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(.gray)
                .padding(.leading, 30)
        }
            
            
            ZStack{
                
            VStack{
            
                Text("")
                   
            }
            .frame(width: 360, height: 225)
            .background(Color.text2dark)
            .cornerRadius(40)
            .offset(x: 6, y: 13)
                
            VStack{
                HStack{
                VStack{
                    Text("Abs-workout")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                    Text("Core, Lower")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundColor(.gray)
                        .offset(x: -70)
                    }
                    .padding(.leading, 30)
                    .offset(y: -20)
                    Spacer()
                }
                HStack{
                    Text("Duration")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                    ZStack{
                        RoundedRectangle(cornerRadius: 20)
                            .frame(width: 45, height: 20)
                            .foregroundColor(.white)
                        HStack{
                        Circle()
                            .frame(width: 6, height: 6)
                        Circle()
                                .frame(width: 6, height: 6)
                                .foregroundColor(.gray)
                        Circle()
                                .frame(width: 6, height: 6)
                                .foregroundColor(.gray)
                        }
                        //.offset(y: 15)
                    }
                    HStack{
                    Text("Difficulty")
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        ZStack{
                            RoundedRectangle(cornerRadius: 20)
                                .frame(width: 45, height: 20)
                                .foregroundColor(.white)
                            HStack{
                            Circle()
                                .frame(width: 6, height: 6)
                            Circle()
                                    .frame(width: 6, height: 6)
                                    .foregroundColor(.gray)
                            Circle()
                                    .frame(width: 6, height: 6)
                                    .foregroundColor(.gray)
                            }
                            
                        }
                        .padding(.leading, 20)
                    }
                    
                }
                .offset(y: 15)
            }
            .frame(width: 360, height: 225)
            .background(Color.text1light)
            .cornerRadius(40)
        }
            .padding(.vertical, 20)
            
            
            //MARK: - Card Type Widget
            VStack(alignment: .leading){
            Text("Categories")
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundColor(.gray)
                .padding(.leading, 94)
            HStack{
                ForEach(cardsType){item in
                    card(cards: item)
                }
                
            }
        }
        .padding(.vertical, 20)
            
            HStack(spacing: 60){
                Image(systemName: "house")
                    .font(.system(size: 27))
                Image(systemName: "line.diagonal")
                    .font(.system(size: 27))
                Image(systemName: "person.2")
                    .font(.system(size: 27))
                Image(systemName: "person.crop.circle")
                    .font(.system(size: 27))
              
            }
            .padding(.top, 20)
            
    }
        
    }
}

extension Color {
    
    static let lightGreen = Color.init(red: 8/255, green: 217/255, blue: 214/255)
    static let colorcard1 = Color.init(red: 63/255, green: 114/255, blue: 175/255)
    static let colorcard2 = Color.init(red: 219/255, green: 226/255, blue: 239/255)
    static let text1dark = Color.init(red: 37/255, green: 42/255, blue: 52/255)
    static let text2dark = Color.init(red: 240/255, green: 240/255, blue: 240/255)
    static let text1light = Color.init(red: 249/255, green: 247/255, blue: 247/255)
    static let color1 = Color(#colorLiteral(red: 0.9434547492, green: 0.9603868688, blue: 0.9555709441, alpha: 1))
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct cards : Identifiable{
    //var id: ObjectIdentifier
    
   var id = UUID()
    var title: String
    var image: String
    var background: Color
    var text: Color
}

let cardsType = [
    cards(title: "Cardio", image: "Cardio", background: Color.colorcard1, text: Color.text1light),
    cards(title: "Workout", image: "Workout", background: Color.colorcard2, text: Color.text1dark),
    cards(title: "Yoga", image: "Yoga", background: Color.colorcard1, text: Color.text1light)
]

struct card: View {
    var cards: cards
    
    var body: some View{
    ZStack {
        Image(cards.image)
            .resizable()
           // .blendMode(.plusDarker)
            .frame(width: 100, height: 100)
            .offset(y:22)
        Text(cards.title)
            .font(.system(size: 24, weight: .bold, design: .rounded))
            .foregroundColor(cards.text)
            .offset(x: -20, y:-70)
    }
    .frame(width: 175, height: 240)
    .background(cards.background)
    .cornerRadius(40)
}
}
