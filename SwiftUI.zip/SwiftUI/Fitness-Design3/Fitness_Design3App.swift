//
//  Fitness_Design3App.swift
//  Fitness-Design3
//
//  Created by Alexandru Bardea on 20/03/2021.
//

import SwiftUI

@main
struct Fitness_Design3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
